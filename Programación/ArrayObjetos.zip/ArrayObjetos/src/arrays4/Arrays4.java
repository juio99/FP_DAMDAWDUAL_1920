package arrays4;

import java.util.Scanner;

public class Arrays4 {
	int[] array;
	
	public Arrays4(int tam) {
		array=new int[tam];
	}
	
	public void rellenar() {
    	for(int i=0;i<array.length;i++)   		
    		array[i]=(int)(Math.random()*101-50);   //genera entre -50 y 50	
    }
    
	
	public void rellenar(Scanner teclado) {    	
    	for(int i=0;i<array.length;i++) {
    		System.out.println("Introducir valor de la componente "+i);
    		array[i]=teclado.nextInt();  		
    	}
    	
    }
	
    public void escribir() {
    	for(int i=0;i<array.length;i++) 
    		System.out.print(array[i]+" ");    		
    }
    
    public double mediaPos(){
    	int suma=0,cont=0;
    	double media=0;
    	
    	for(int i=0;i<array.length;i++)
    		if(array[i]>=0){
    		  suma=suma+array[i];
    		  cont++;
    		}

    	if (cont==0)
    	  System.out.println("No hay numeros positivos en el array");
    	else
    		media=(double)suma/cont;
    	
    	return media;
    }
    
    public double mediaNeg(){
    	int suma=0,cont=0;
    	double media=0;
    	for(int i=0;i<array.length;i++)
    		if(array[i]<0){
    		  suma=suma+array[i];
    		  cont++;
    		}
    	
    	if (cont==0)
    	  System.out.println("No hay numeros negativos en el array");
    	else
    		media=(double)suma/cont;
    	return media;
    }
}
