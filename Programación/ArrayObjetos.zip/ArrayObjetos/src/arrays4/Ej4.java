package arrays4;
import java.util.Scanner;

public class Ej4 {
	final static int TAM=10;
	
	public static void main(String[] args) {
	
		Scanner sc = new Scanner(System.in);
        
		Arrays4 objArray = new Arrays4(TAM);
		
		objArray.rellenar();
		objArray.rellenar(sc);
		
		objArray.escribir();
        
        System.out.println();
        System.out.println("La media de los numeros positivos es " + objArray.mediaPos());
        System.out.println("La media de los numeros negativos es " + objArray.mediaNeg());
        
        sc.close();
	}
   
	
	
}

