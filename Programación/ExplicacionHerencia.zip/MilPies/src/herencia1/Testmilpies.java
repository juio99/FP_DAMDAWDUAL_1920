package herencia1;

public class Testmilpies {
	 public static void main(String[] args){
		 //El constructor de MilpiesEsquiador ejecuta el constructor padre, pero el m�todo propio
		 MilpiesEsquiador mE = new MilpiesEsquiador();
		 
		 //Milpies m = new Milpies();
	}    
}  

