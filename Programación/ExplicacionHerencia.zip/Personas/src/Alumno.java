
//Clase Alumno. Clase derivada de Persona
import java.util.*;

public class Alumno extends Persona {
	private String curso;

	public Alumno() {
		System.out.println("Ejecutando el constructor por defecto de Alumno");
	}

	public Alumno(String nif, String nombre, String curso) {
		super(nif, nombre);
		this.curso = curso;
	}

	public String getCurso() {
		return curso;
	}

	public void setCurso(String curso) {
		this.curso = curso;
	}

	@Override // indica que se modifica un m�todo heredado
	public void leer(Scanner sc) {

		super.leer(sc); // se llama al m�todo leer de Persona para leer nif y nombre
		System.out.print("Curso: ");
		curso = sc.nextLine(); // se lee el curso

	}

	public String toString() {
		return super.toString() + " Curso: " + curso;
	}
}
