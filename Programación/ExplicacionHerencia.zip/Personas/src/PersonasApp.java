import java.util.Scanner;

public class PersonasApp {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		Alumno a1 = new Alumno("12345678-Z", "Eliseo Gonz�lez Manzano", "1DAW");
		Alumno a2 = new Alumno();
		// Aunque no es la mejor forma, por ver como usa herencia
		a2.leer(sc);
		System.out.println(a1);
		System.out.println(a2);
	}

}
