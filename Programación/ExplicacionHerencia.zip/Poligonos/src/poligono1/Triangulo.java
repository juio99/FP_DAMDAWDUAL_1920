package poligono1;

public class Triangulo extends Poligono
{
	public Triangulo (){
		System.out.println("Triangulo()");
	}
}


