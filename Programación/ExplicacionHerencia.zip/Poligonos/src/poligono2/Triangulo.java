package poligono2;

public class Triangulo extends Poligono
{
	// Para tener el constructor por defecto, si he escrito el constructor
	// con par�metros, necesito el constructor por defecto de Pol�gono
	// o alguno por defecto en las superclases
	/*public Triangulo (){		
		System.out.println("Triangulo()");
	}*/
	
	public Triangulo (String str) {
		// Si no invoco el constructor con par�metro (super(str);), llamar� al constructor sin par�metros
		
		//super();//Probar con y sin esta sentencia
		
		/*
		Figura()
		Poligono()
		Triangulo(Hola)
		Dibujo Poligono
		*/
		
		//super(str);//Probar con y sin esta sentencia, si no llamo a ning�n constructor se invoca el de por defecto
		
		/*
		Figura(Hola)
		Poligono(Hola)
		Triangulo(Hola)
		Dibujo Poligono
		*/
		System.out.println("Triangulo("+ str + ")");
	}
}


