package poligono2;

public class Figura
{
	public Figura (){		
		System.out.println("Figura()");
	}
	
	public Figura (String str) {
		System.out.println("Figura("+ str + ")");
	}
	public void Dibujar()	{
		System.out.println("Dibujo Figura");
	}
}
