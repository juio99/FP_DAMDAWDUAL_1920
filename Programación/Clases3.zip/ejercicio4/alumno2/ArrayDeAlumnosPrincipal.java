
package ejercicio4.alumno2;

/**
 * ArrayDeAlumnosPrincipal.java
 * Programa que prueba un array de la clase Alumno
 */
import java.util.Scanner;

public class ArrayDeAlumnosPrincipal {

	public static final int MAX_OPC = 6;
	public static final int NUMAL = 5;

	static int menu(int tope_op, Scanner sc) {
		int opcion_menu;

		System.out.println();
		System.out.println("\t1. Introducir Alumno");
		System.out.println("\t2. Mostrar todos los alumnos");
		System.out.println("\t3. Mostrar alumnos con nota media de aprobado");
		System.out.println("\t4. Mostrar alumnos con nota media de suspenso");
		System.out.println("\t5. Mostrar la nota media de la clase");
		System.out.println("\t6. Salir.");
		do {
			System.out.print("\n\n\tElija opcion:");
			// opcion_menu=sc.nextInt(); Evitamos que el salto de linea se quede en el
			// buffer
			opcion_menu = Integer.parseInt(sc.nextLine());
		} while (opcion_menu < 1 || opcion_menu > tope_op);

		return opcion_menu;
	}

	public static void main(String[] args) {

		int opcion = 0;

		// Define la estructura, un array 
		// pero no crea los objetos
		Alumno[] alumnos = new Alumno[NUMAL];
		Scanner sc = new Scanner(System.in);

		while (opcion != MAX_OPC) {
			opcion = menu(MAX_OPC, sc);
			switch (opcion) {
			case 1:
				aniadirAlumnos(alumnos, sc);
				break;
			case 2:
				mostrarAlumnos(alumnos);
				break;
			case 3:
				int numAprobados = devolverAprobados(alumnos);
				if (numAprobados != -1) {
					System.out.println("Alumnos aprobados: " + numAprobados);
					System.out.println();
				} else
					System.out.println("No hay alumnos");
				break;
			case 4:
				int numSuspensoss = devolverSuspensos(alumnos);
				if (numSuspensoss != -1) {
					System.out.println("Alumnos suspensos: " + numSuspensoss);
					System.out.println();
				} else
					System.out.println("No hay alumnos");
				break;

			case 5:
				double media = devolverMedia(alumnos);
				if (media != -1) {
					System.out.print("La media de la clase es: ");
					System.out.printf("%.2f", media);
				} else
					System.out.println("No hay alumnos");
				break;

			}
		}

		sc.close();
	}

	private static Alumno leerAlumno(Scanner sc) {
		System.out.println("Introducir un nuevo alumno");

		System.out.println("Dame nombre: ");
		String nombre = sc.nextLine();
		System.out.println("Dame apellido: ");
		String apellido = sc.nextLine();
		System.out.println("Dame nota: ");
		double nota = Double.parseDouble(sc.nextLine());

		return new Alumno(nombre, apellido, nota);
	}

	private static void aniadirAlumnos(Alumno al[], Scanner sc) {
		if (Alumno.getNumAl() < NUMAL) {
			al[Alumno.getNumAl()] = leerAlumno(sc);
		} else
			System.out.println("No hay espacio para m�s alumnos");

	}

	private static void mostrarAlumnos(Alumno al[]) {
		if (Alumno.getNumAl() > 0) {
			System.out.println("Alumnos:");
			for (int i = 0; i < Alumno.getNumAl(); i++) {
				System.out.println("/******************/");
				System.out.println(al[i]);
			}
		} else
			System.out.println("No hay alumnos");

	}

	private static int devolverAprobados(Alumno al[]) {
		if (Alumno.getNumAl() > 0) {
			int numAprobados = 0;

			for (int i = 0; i < Alumno.getNumAl(); i++) {
				if (al[i].getNotaMedia() >= 5)
					numAprobados++;
			}

			return numAprobados;
		} else
			return -1;
	}

	private static int devolverSuspensos(Alumno al[]) {
		if (Alumno.getNumAl() > 0) {
			int numSuspensos = 0;

			for (int i = 0; i < Alumno.getNumAl(); i++) {
				if (al[i].getNotaMedia() < 5)
					numSuspensos++;
			}

			return numSuspensos;
		} else
			return -1;
	}

	private static double devolverMedia(Alumno al[]) {
		if (Alumno.getNumAl() > 0) {
			double notaT = 0;

			int numAl = Alumno.getNumAl();

			for (int i = 0; i < numAl; i++)
				notaT += al[i].getNotaMedia();

			return notaT / numAl;
		} else
			return -1;
	}
}
