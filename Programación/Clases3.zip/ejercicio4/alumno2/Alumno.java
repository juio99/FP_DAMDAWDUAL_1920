package ejercicio4.alumno2;
/**
 * Alumno.java
 * Definicion de la clase Alumno
 */

public class Alumno {
  private String nombre, apellido;
  private double notaMedia = 0.0;
  private static int numAl = 0;
  
  public Alumno(String nombre, String apellido, double nota) {
	  this.nombre = nombre;
	  this.apellido = apellido;
	  this.notaMedia = nota;
	  numAl++;
  }
  
  public static int getNumAl() {
	    return numAl;
  }
  
  public String getNombre() {
    return nombre;
  }
  
  public String getApellido() {
	    return apellido;
  }
  
  public void setNombre(String nombre) {
    this.nombre = nombre;
  }
  
  public void setApellido(String apellido) {
	    this.apellido = apellido;
  }
  
  public double getNotaMedia() {
    return notaMedia;
  }

  public void setNotaMedia(double notaMedia) {
    this.notaMedia = notaMedia;
  }
  
  public String toString() {
	  return "Nombre: " + nombre + "\nApellido: " + apellido + "\nNota media: " + notaMedia;
  }
}
