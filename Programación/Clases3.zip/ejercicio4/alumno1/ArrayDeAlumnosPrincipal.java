/**
 * ArrayDeAlumnosPrincipal.java
 * Programa que prueba un array de la clase Alumno
 */
package ejercicio4.alumno1;

import java.util.Scanner;

public class ArrayDeAlumnosPrincipal {
	
public static final int MAX_OPC=4;
	
  static int menu(int tope_op, Scanner sc)
  {
		int opcion_menu;
		
		System.out.println();
	    System.out.println("\t1. Introducir Alumno");
		System.out.println("\t2. Mostrar alumnos con nota media de aprobado");
		System.out.println("\t3. Mostrar alumnos con nota media de suspenso");
		System.out.println("\t4. Salir.");
		do
		{
			System.out.print("\n\n\tElija opcion:");
			//opcion_menu=sc.nextInt(); Evitamos que el salto de linea se quede en el buffer
			opcion_menu=Integer.parseInt(sc.nextLine());
		} while (opcion_menu  < 1 || opcion_menu > tope_op);
		
	    return opcion_menu;
  }
	
  public static void main(String[] args) {
    final int NUMAL = 5;
    int opcion=0;
    
    // Define la estructura, un array de 5 alumnos
    // pero no crea los objetos
    Alumno[] alumnos = new Alumno[NUMAL];
    Scanner sc = new Scanner(System.in);
    
    while (opcion != MAX_OPC)
	{
		opcion = menu(MAX_OPC, sc);
		switch (opcion)
      	{
         case 1:
        	 	 alumnos[Alumno.getNumAl()] = leerAlumno(sc);
                 break;
         case 2:
     			 System.out.println(devolverAprobados(alumnos));
                 break;
         case 3:
        	 	 System.out.println(devolverSuspensos(alumnos));
 			 	 break;
     	}
     }
   
    sc.close();
  }
  
  private static Alumno leerAlumno(Scanner sc) {
	  System.out.println("Introducir un nuevo alumno");
      
      System.out.println("Dame nombre: ");
      String nombre = sc.nextLine();
      System.out.println("Dame apellido: ");
      String apellido = sc.nextLine();
      System.out.println("Dame nota: ");
      double nota = Double.parseDouble(sc.nextLine());
      
      return new Alumno(nombre, apellido, nota);
  }
  
  private static int devolverAprobados(Alumno al[]) {
	 int numAprobados=0;
	 System.out.println("Muestra alumnos aprobados");
	 for (int i=0; i<Alumno.getNumAl(); i++) {
		if (al[i].getNotaMedia() >= 5)
			numAprobados++;   					
	 }
	 return numAprobados;
  }
  
  private static int devolverSuspensos(Alumno al[]) {
		 int numSuspensos=0;
		 System.out.println("Muestra alumnos suspensos");
		 for (int i=0; i<Alumno.getNumAl(); i++) {
			if (al[i].getNotaMedia() < 5)
				numSuspensos++;   					
		 }
		 return numSuspensos;
	  }
}
