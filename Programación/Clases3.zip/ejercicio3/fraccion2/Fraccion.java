package ejercicio3.fraccion2;

public class Fraccion {
	private int num;
	private int den;

	public Fraccion() {
		num = 0;
		den = 1;
	}

	public Fraccion(int x, int y) {
		num = x;
		den = y;
	}

	public Fraccion sumar(Fraccion a) {
		Fraccion c = new Fraccion();
		c.num = num * a.den + a.num * den;
		c.den = den * a.den;
		return c;
	}

	public Fraccion restar(Fraccion a) {
		Fraccion c = new Fraccion();
		c.num = num * a.den - a.num * den;
		c.den = den * a.den;
		return c;
	}

	public Fraccion multiplicar(Fraccion a) {
		return new Fraccion(num * a.num, den * a.den);
	}

	public Fraccion inversa() {
		return new Fraccion(den, num);
	}

	public Fraccion dividir(Fraccion a) {
		return multiplicar(a.inversa());
	}

	// Se divide el n�mero mayor entre el menor.
	// Si:

	// La divisi�n es exacta, el divisor es el m.c.d.
	// La divisi�n no es exacta, dividimos el divisor entre el resto obtenido y se
	// contin�a
	// de esta forma hasta obtener una divisi�n exacta, siendo el �ltimo divisor el
	// m.c.d.
	private int mcd() {
		int u, v;
		int t;

		// En u se pone el m�s grande
		if (num > den) {
			u = num;
			v = den;
		} else {
			u = den;
			v = num;
		}
		
		while (v != 0) {
			t = v;
			v = u % v;
			u = t;
		}
		return u;
	}

	public Fraccion simplificar() {
		int dividir = mcd();
		num /= dividir;
		den /= dividir;
		return this;
	}

	public String toString() {
		String texto = num + " / " + den;
		return texto;
	}
}
