package ejercicio3.fraccion2;

public class FraccionApp {
	
  static public void main(String[] args) {
	 // Cambiar para pedir datos al usuario
	 // Obligatorio que sean valores positivos y mayores que cero
	 Fraccion resultado;
	  
     Fraccion x=new Fraccion(6,3);
     Fraccion y=new Fraccion(3,4);
     Fraccion z=new Fraccion(1,2);
     System.out.println("x--> "+x);
     System.out.println("y--> "+y);
     System.out.println("z--> "+z);

     System.out.println();
          
     System.out.println(" Sumamos x con y ");
     resultado = x.sumar(y);
     System.out.println("x+y= " + resultado);
     System.out.println(" Simplificamos ");
     System.out.println("x+y= "  + resultado.simplificar());

     System.out.println();
          
     System.out.println(" Multiplicamos x por y ");
     resultado = x.multiplicar(y);
     System.out.println("x*y= "+resultado);
     System.out.println(" Simplificamos ");
     System.out.println("x*y= "+resultado.simplificar());
     
     System.out.println();
     
     System.out.println(" Sumamos x con y y luego hacemos el producto con z ");
     resultado = x.sumar(y).multiplicar(z);
     System.out.println("(x+y)*z= "+resultado);
     System.out.println(" Simplificamos ");
     System.out.println("(x+y)*z= "+resultado.simplificar());

     System.out.println();
     
     System.out.println(" Restamos x de y ");
     System.out.println("x-y= "+ (resultado=x.restar(y)));
     System.out.println(" Simplificamos");
     System.out.println("x-y= "+ resultado.simplificar());

     System.out.println();
     
     System.out.println(" Dividimos x entre y ");
     System.out.println("x/y= "+ (resultado=x.dividir(y)));
     System.out.println(" Simplificamos");
     System.out.println("x/y= " + resultado.simplificar());

     try  {
//espera la pulsaci�n de una tecla y luego RETORNO
            System.in.read();
        }catch (Exception e) {  }
    }
}