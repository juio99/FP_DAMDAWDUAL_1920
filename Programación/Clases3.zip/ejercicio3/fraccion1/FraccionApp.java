package ejercicio3.fraccion1;

public class FraccionApp {
	private static int mcd(int num, int den){
		 int u, v;
	    
		 if (num>den) 	{u = num; v=den;}
	     else 			{v = num; u=den;}
	    
	     int r=u%v;
	     
	     while(r>0){	         
	          u=v;
	          v=r;
	          r=u%v;
	     }
	     
	     return v;
	  }
	
  static public void main(String[] args) {
	 // Cambiar para pedir datos al usuario
	 // Obligatorio que sean valores positivos y mayores que cero
	 System.out.println (mcd(72, 16));
     Fraccion x=new Fraccion(2,3);
     Fraccion y=new Fraccion(4,3);
     Fraccion z=new Fraccion(1,2);
     System.out.println("x--> "+x);
     System.out.println("y--> "+y);
     System.out.println("z--> "+z);
     System.out.println(" Sumamos x con y ");
     System.out.println("x+y= "+Fraccion.sumar(x, y));
     System.out.println(" Multiplicamos x por y ");
     System.out.println("x*y= "+Fraccion.multiplicar(x,y));
     System.out.println(" Sumamos x con y y luego hacemos el producto con z ");
     Fraccion resultado=Fraccion.multiplicar(Fraccion.sumar(x,y),z);
     System.out.println("(x+y)*z= "+resultado);
     System.out.println(" Simplificamos");
     System.out.println(resultado.simplificar());
     

     try  {
//espera la pulsaci�n de una tecla y luego RETORNO
            System.in.read();
        }catch (Exception e) {  }
    }
}