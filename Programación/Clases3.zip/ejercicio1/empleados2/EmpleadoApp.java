package ejercicio1.empleados2;

import javax.swing.JOptionPane;

public class EmpleadoApp {

	public static void main(String[] args) {
		final int NUM = 3;
		// Creamos varios empleados

		// Creamos un array de objetos de la clase empleados
		Empleado empleados[] = new Empleado[NUM];

		// Creamos n empleados y rellenamos todos
		double suma = 0;
		for (int i = 0; i < empleados.length; i++) {
			empleados[i] = leerEmpleado();
			JOptionPane.showMessageDialog(null, empleados[i].toString(), "Datos Empleado",
					JOptionPane.INFORMATION_MESSAGE);
		}

		// Lo recorremos y sumamos los salarios
		for (int i = 0; i < empleados.length; i++) {
			suma += empleados[i].getSalario();
		}

		JOptionPane.showMessageDialog(null, "La suma de salarios es " + suma, null, JOptionPane.INFORMATION_MESSAGE);
		// Comprobamos si les corresponde subida y en ese caso volvemos a imprimir el
		// sueldo
		JOptionPane.showMessageDialog(null, "Nuevos sueldos", null, JOptionPane.INFORMATION_MESSAGE);

		for (int i = 0; i < empleados.length; i++) {
			if (empleados[i].comprobarPlus(120)) // mas adelante lo pedimos por programa
				JOptionPane.showMessageDialog(null, empleados[i].toString(), "Nuevo sueldo Empleado",
						JOptionPane.INFORMATION_MESSAGE);
		}

		suma = 0;
		// Lo recorremos y sumamos de nuevo los salarios
		for (int i = 0; i < empleados.length; i++) {
			// Mostramos la direccion del objeto
			suma += empleados[i].getSalario();
		}

		JOptionPane.showMessageDialog(null, "La nueva suma de salarios es " + suma, null,
				JOptionPane.INFORMATION_MESSAGE);
	}

	/***********************************************************************/
	/* leerEmpleado: pide al usuario los datos de un empleado y devuelve */
	/* un objeto Empleado partir de esos valores */
	/***********************************************************************/
	public static Empleado leerEmpleado() {
		String nombre = JOptionPane.showInputDialog("Escribe un nombre");

		String apellido = JOptionPane.showInputDialog("Escribe un apellido");
		String texto = null;

		int edad = 0;
		do {
			texto = JOptionPane.showInputDialog("Escribe una edad");
		} while (!esEntero(texto));
		edad = Integer.parseInt(texto);

		double salario = 0;
		do {
			texto = JOptionPane.showInputDialog("Escribe un salario");
		} while (!esDouble(texto));
		salario = Double.parseDouble(texto);

		// Empleado empleado=new Empleado(nombre, apellido, edad, salario);

		return new Empleado(nombre, apellido, edad, salario);

	}

	/***********************************************************************/
	/* esEntero: pide al usuario un valor entero y devuelve true si es */
	/* un numero, falso en caso contrario */
	/***********************************************************************/
	public static boolean esEntero(String cadena) {

		boolean resultado;

		try {
			Integer.parseInt(cadena);
			resultado = true;
		} catch (NumberFormatException excepcion) {
			resultado = false;
		}

		return resultado;
	}

	/***********************************************************************/
	/* esDouble: pide al usuario un valor entero y devuelve true si es */
	/* un numero, falso en caso contrario */
	/***********************************************************************/
	public static boolean esDouble(String cadena) {

		boolean resultado;

		try {
			Double.parseDouble(cadena);
			resultado = true;
		} catch (NumberFormatException excepcion) {
			resultado = false;
		}

		return resultado;
	}
}
