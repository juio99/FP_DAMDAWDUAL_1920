package ejercicio1.empleados1;
import javax.swing.JOptionPane;

public class EmpleadoApp {

	public static void main(String[] args) {
		Empleado empleado1, empleado2, empleado3;
		//Creamos 3 empleados
		
		empleado1 = leerEmpleado();
		System.out.println( "\nEmpleado 1:\n" + empleado1);
		JOptionPane.showMessageDialog(null, empleado1.toString(), "Datos Empleado1", JOptionPane.INFORMATION_MESSAGE);

		empleado2=new Empleado();
		// Este empleado tiene los datos por defecto:
		System.out.println( "\nEmpleado 2:\n" + empleado2);
		JOptionPane.showMessageDialog(null, empleado2.toString(), "Datos Empleado2", JOptionPane.INFORMATION_MESSAGE);
		
		empleado3 = leerEmpleado();
		System.out.println( "\nEmpleado 3:\n" + empleado3);
		JOptionPane.showMessageDialog(null, empleado3.toString(), "Datos Empleado3", JOptionPane.INFORMATION_MESSAGE);
		
		// Comprobamos si les corresponde subida y en ese caso volvemos a imprimir el sueldo
		JOptionPane.showMessageDialog(null, "Nuevos sueldos", null, JOptionPane.INFORMATION_MESSAGE);
		
		if (empleado1.comprobarPlus(120))
			JOptionPane.showMessageDialog(null, empleado1.toString(), "Nuevo sueldo Empleado1", JOptionPane.INFORMATION_MESSAGE);
		if (empleado2.comprobarPlus(120))
			JOptionPane.showMessageDialog(null, empleado2.toString(), "Nuevo sueldo Empleado2", JOptionPane.INFORMATION_MESSAGE);
		if (empleado3.comprobarPlus(120))
			JOptionPane.showMessageDialog(null, empleado3.toString(), "Nuevo sueldo Empleado3", JOptionPane.INFORMATION_MESSAGE);
	}
	
	public static Empleado leerEmpleado() {
		String nombre=JOptionPane.showInputDialog("Escribe un nombre");

		String apellido=JOptionPane.showInputDialog("Escribe un apellido");

		String texto=JOptionPane.showInputDialog("Escribe una edad");
		int edad=Integer.parseInt(texto);

		texto=JOptionPane.showInputDialog("Escribe un salario");
		double salario=Double.parseDouble(texto);

		//Empleado empleado=new Empleado(nombre, apellido, edad, salario);
		
		return new Empleado(nombre, apellido, edad, salario);
	
	}
	
	

}

