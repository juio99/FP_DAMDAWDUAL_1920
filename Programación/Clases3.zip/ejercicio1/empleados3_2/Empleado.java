package ejercicio1.empleados3_2;

/**
 * Clase Empleado
 *
 * Contiene informacion de cada empleado
 *
 * @author Esther
 * @version 1.0
 */
public class Empleado {
	// Atributos
	/**
	 * atributo para uso interno hacemos geter y seter por si hay que resetearlo
	 * para posteriores subidas pero no los estoy usando, ya que accedo directamente
	 * a los atributos. En ppio solo se usan dentro de la clase.
	 */
	private boolean cambiado = false;
	/**
	 * Nombre del empleado
	 */
	private String nombre;
	/**
	 * Apellido del empleado
	 */
	private String apellido;
	/**
	 * Edad del empleado
	 */
	private int edad;
	/**
	 * Salario del empleado
	 */
	private double salario;

	private static int numEmp = 0;
	// Metodos

	// Constructores
	/**
	 * Constructor por defecto
	 */
	public Empleado() {
		/*
		 * this.nombre=""; this.apellido=""; this.edad=0; this.salario=0;
		 */
		numEmp++;
	}

	/**
	 * Constructor con 4 parametros
	 * 
	 * @param nombre   nombre del empleado
	 * @param apellido nombre del empleado
	 * @param edad     edad del empleado
	 * @param salario  salario del empleado
	 */
	public Empleado(String nombre, String apellido, int edad, double salario) {
		this.nombre = nombre;
		this.apellido = apellido;
		this.edad = edad;
		this.salario = salario;
		numEmp++;
	}

	private boolean isCambiado() {
		return cambiado;
	}

	private void setCambiado(boolean cambiado) {
		this.cambiado = cambiado;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public void setApellido(String apellido) {
		this.nombre = apellido;
	}

	public void setEdad(int edad) {
		this.edad = edad;
	}

	public void setSalario(double salario) {
		this.salario = salario;
	}

	public String getNombre() {
		return nombre;
	}

	public String getApellido() {
		return apellido;
	}

	public int getEdad() {
		return edad;
	}

	public double getSalario() {
		return salario;
	}

	public static int getNumEmp() {
		return numEmp;
	}

	/**
	 * Suma un plus al salario del empleado si el empleado tiene mas de 40 a�os
	 * 
	 * @param sueldoPlus
	 *
	 */
	public boolean comprobarPlus(double sueldoPlus) {
		boolean aumento = false;
		
		if (edad > 40 && !cambiado) {
			salario += sueldoPlus;
			aumento = true;
			cambiado = true;
		}
		
		return aumento;
	}

	public String toString() {
		return "\nNombre: " + nombre + "\nApellido: " + apellido + "\nEdad: " + edad + "\nSalario: " + salario;
	}

}