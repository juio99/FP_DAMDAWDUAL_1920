package ejercicio1.empleados3_2;

import javax.swing.JOptionPane;

public class EmpleadoApp {
	public static final int MAX_OPC = 5;

	static int menu(int tope_op) {
		int opcion_menu;

		System.out.println();
		opcion_menu = Integer
				.parseInt(JOptionPane.showInputDialog("\nElija opcion:\n\n\t1. Nuevo empleado \n\t2. Mostrar empleados"
						+ "\n\t3. Aplicar plus a empleados \n\t4. Mostrar salario total \n\t5. Salir.\n\n"));

		while (opcion_menu < 1 || opcion_menu > tope_op) {
			opcion_menu = Integer.parseInt(
					JOptionPane.showInputDialog("\nElija opcion:\n\n\t1. Nuevo empleado \n\t2. Mostrar empleados"
							+ "\n\t3. Aplicar plus a empleados \n\t4. Mostrar salario total \n\t5. Salir.\n\n"));
		}

		return opcion_menu;
	}

	/*
	 * Mejoramos con metodos para implementar las opciones del menu y queda mas
	 * limpio el codigo
	 * 
	 */
	public static void main(String[] args) {
		final int NUM = 3;
		int opcion = 0;

		// Creamos un array de objetos de la clase empleados
		Empleado empleados[] = new Empleado[NUM];

		while (opcion != MAX_OPC) {
			opcion = menu(MAX_OPC);
			switch (opcion) {
			case 1:
				rellenaEmpleados(empleados);
				break;
			case 2:
				mostrarEmpleados(empleados);
				break;
			case 3:
				subePlus(empleados);
				break;
			case 4:
				sumaTotal(empleados);
				break;
			}
		}
		// Hay un error: si pasamos por subida de plus, no debemos aumentar el salario a
		// los empleados a los que ya
		// les haya aumentado en otra pasada. Proponed soluciones y supuestos.

	}

	/***********************************************************************/
	/* leerEmpleado: pide al usuario los datos de un empleado y devuelve */
	/* un objeto Empleado partir de esos valores */
	/***********************************************************************/
	public static Empleado leerEmpleado() {
		String nombre = JOptionPane.showInputDialog("Escribe un nombre");

		String apellido = JOptionPane.showInputDialog("Escribe un apellido");
		String texto = null;

		int edad = 0;
		do {
			texto = JOptionPane.showInputDialog("Escribe una edad");
		} while (!esEntero(texto));
		edad = Integer.parseInt(texto);

		double salario = 0;
		do {
			texto = JOptionPane.showInputDialog("Escribe un salario");
		} while (!esDouble(texto));
		salario = Double.parseDouble(texto);

		// Empleado empleado=new Empleado(nombre, apellido, edad, salario);

		return new Empleado(nombre, apellido, edad, salario);

	}

	/***********************************************************************/
	/* esEntero: pide al usuario un valor entero y devuelve true si es */
	/* un numero, falso en caso contrario */
	/***********************************************************************/
	public static boolean esEntero(String cadena) {

		boolean resultado;

		try {
			Integer.parseInt(cadena);
			resultado = true;
		} catch (NumberFormatException excepcion) {
			resultado = false;
		}

		return resultado;
	}

	/***********************************************************************/
	/* esDouble: pide al usuario un valor entero y devuelve true si es */
	/* un numero, falso en caso contrario */
	/***********************************************************************/
	public static boolean esDouble(String cadena) {

		boolean resultado;

		try {
			Double.parseDouble(cadena);
			resultado = true;
		} catch (NumberFormatException excepcion) {
			resultado = false;
		}

		return resultado;
	}

	/**************************************************************************/
	/* rellenaEmpleados: pide al usuario los datos de un empleado y rellena */
	/* la posici�n correspondiente con un empleado */
	/**************************************************************************/
	public static void rellenaEmpleados(Empleado[] emp) {
		int pos = Empleado.getNumEmp();
		
		if (pos < emp.length) {
			emp[pos] = leerEmpleado();
			JOptionPane.showMessageDialog(null, emp[pos].toString(), "Datos Empleado", JOptionPane.INFORMATION_MESSAGE);
		} else
			JOptionPane.showMessageDialog(null, "No puede introducir mas empleados");

	}

	/****************************************************************************/
	/* mostrarEmpleados: muestra los datos de todos los empleados que tengamos */
	/* hasta el momento */
	/****************************************************************************/
	public static void mostrarEmpleados(Empleado[] emp) {
		int pos;

		if ((pos = Empleado.getNumEmp()) > 0)
			for (int i = 0; i < pos; i++)
				JOptionPane.showMessageDialog(null, emp[i].toString(), "Datos Empleado",
						JOptionPane.INFORMATION_MESSAGE);
		else
			JOptionPane.showMessageDialog(null, "No hay empleados.", null, JOptionPane.INFORMATION_MESSAGE);
	}

	/**************************************************************************/
	/* subePlus: pide al usuario la cantidad del plus y sube a los empleados */
	/* que deban recibirlo */
	/**************************************************************************/
	public static void subePlus(Empleado[] emp) {
		int pos;

		if ((pos = Empleado.getNumEmp()) > 0) {
			double sueldoPlus = Integer
					.parseInt(JOptionPane.showInputDialog("\nIntroduce nueva subida para mayores de 40 a�os.\n"));
			for (int i = 0; i < pos; i++)
				emp[i].comprobarPlus(sueldoPlus);
		} else
			JOptionPane.showMessageDialog(null, "No hay empleados.", null, JOptionPane.INFORMATION_MESSAGE);
	}

	/**************************************************************************/
	/* sumaTotal: muestra el sueldo total de los empleados */
	/**************************************************************************/
	public static void sumaTotal(Empleado[] emp) {
		int pos;
		double suma = 0;

		if ((pos = Empleado.getNumEmp()) > 0) {
			suma = 0;
			for (int i = 0; i < pos; i++)
				suma += emp[i].getSalario();
			JOptionPane.showMessageDialog(null, "La suma total de sueldos es " + suma + " euros.", null,
					JOptionPane.INFORMATION_MESSAGE);
		} else
			JOptionPane.showMessageDialog(null, "No hay empleados.", null, JOptionPane.INFORMATION_MESSAGE);
	}
}
