package ejercicio1.empleadosPrueba;


/**
 * Clase Empleado
 *
 * Contiene informacion de cada empleado
 *
 * @author Esther
 * @version 1.0
 */
public class Empleado {
	//Atributos
	/**
	 * Nombre del empleado
	 */
	private String nombre;
	/**
	 * Apellido del empleado
	 */
	private String apellido;
	/**
	 * Edad del empleado
	 */
	private int edad;
	/**
	 * Salario del empleado
	 */
	private double salario;
	//Metodos
    
	
	//Constructores
         /**
	 * Constructor por defecto
	 */
	public Empleado(){
		/*this.nombre="";
		this.apellido="";
		this.edad=0;
		this.salario=0;*/
	}
         /**
	 * Constructor con 4 parametros
	 * @param nombre nombre del empleado
	 * @param apellido nombre del empleado
	 * @param edad edad del empleado
	 * @param salario salario del empleado
	 */
	public Empleado(String nombre, String apellido, int edad, double salario){
		this.nombre=nombre;
		this.apellido=apellido;
		this.edad=edad;
		this.salario=salario;
	}
	
	public void setNombre(String nombre) {
		this.nombre=nombre;
	}
	
	public void setApellido(String apellido) {
		this.nombre=apellido;
	}
	
	public void setEdad(int edad) {
		this.edad=edad;
	}
	
	public void setSalario(double salario) {
		this.salario=salario;
	}
	
	public String getNombre() {
		return nombre;
	}
	
	public String getApellido() {
		return apellido;
	}
	
	public int getEdad() {
		return edad;
	}
	
	public double getSalario() {
		return salario;
	}
	
	 /**
		 * Suma un plus al salario del empleado si el empleado tiene mas de 40 a�os
		 * @param sueldoPlus
		 *
	*/
	public boolean comprobarPlus (double sueldoPlus){
		boolean aumento=false;
	        
		if (edad>40){
			salario+=sueldoPlus;
			aumento=true;
	    }
	                
		return aumento;
	}
	
	public String toString() {
		return "\nNombre: " + nombre + "\nApellido: " + apellido + "\nEdad: " + edad + "\nSalario: " + salario;
	}
}