package ejercicio2;

import java.util.Scanner;

public class Principal {
	public static Scanner sc = new Scanner(System.in);

	public static void main(String[] args) {

		int longitud, opt, num;
		System.out.println("Introduce el numero maximo de numeros");
		longitud = sc.nextInt();
		Promedio prom = new Promedio(longitud);
		do {
			System.out.print(
					"1) Agregar numero\n2) Obtener promedio\n3) Ver los datos introducidos\n0) Salir\nIntroduce una opcion:\n");
			opt = sc.nextInt();
			switch (opt) {
			case 1:
				System.out.println("Introduce el numero: ");
				num = sc.nextInt();
				prom.agregarNumero(num);
				break;

			case 2:
				System.out.println("El promedio es...");
				System.out.println(prom.obtenerPromedio());
				break;

			case 3:
				System.out.println("Los valores introducidos son los siguientes:");
				prom.mostrarValores();
				System.out.println();
				System.out.println(prom);
				System.out.println();
				break;

			case 0:
				System.out.println("�Hasta luego!");
				opt = 0;
				break;
				
			}

		} while (opt != 0);
	}

}
