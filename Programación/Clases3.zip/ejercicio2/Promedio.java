package ejercicio2;

public class Promedio {

	private int arr[];
	private int contador = 0;

	public Promedio() {
	}

	public Promedio(int longitud) {
		arr = new int[longitud];
	}

	public void agregarNumero(int numero) {
		if (contador < arr.length) {
			arr[contador] = numero;
			contador++;
		} else {
			System.out.println("No se pueden agregar mas numeros");
		}
	}

	public double obtenerPromedio() {
		double promedio = 0;

		for (int i = 0; i < contador; i++) {
			promedio = promedio + arr[i];
		}
		return promedio / contador;
	}

	public void mostrarValores() {
		for (int i = 0; i < contador; i++) {
			System.out.print(arr[i] + " ");
		}
	}

	public String toString() {
		String cadena="";

		for (int i = 0; i < contador; i++)
			cadena += arr[i] + " ";

		return cadena;
	}

}
