package ejercicio5;

/**
 * Cubo.java
 * Definicion de la clase Cubo
 */
public class Cubo {

  // atributos ////////////////////////////

  int capacidad; // capacidad maxima en litros
  int contenido; // contenido actual en litros

  // metodos //////////////////////////////

  // constructor
  Cubo (int c) {
    this.capacidad = c;
	this.contenido = 0; // Aunque lo haria por defecto
  }

  // metodos getter  
  int getCapacidad() {
    return this.capacidad;
  }
  
  int getContenido() {
    return this.contenido;
  }

  // metodo setter
  void setContenido(int litros) {
    this.contenido = litros;
  }

  // otros metodos
  void vacia() {
    this.contenido = 0;
  }

  /**
   * Llena el cubo al maximo de su capacidad.
   */
  void llena() {
    this.contenido = this.capacidad;
  }

  /**
   * Pinta el cubo en la pantalla.
   * Se muestran los bordes del cubo con el caracter # y el
   * agua que contiene con el caracter ~.
   */  
  void pinta() {
    for (int nivel = this.capacidad; nivel > 0; nivel--) {
      if (this.contenido >= nivel) {
        System.out.println("#~~~~#");// Cada litro es una linea de estas
      } else {
        System.out.println("#    #");
      }
    }
    System.out.println("######");
  }

  /**
   * Vuelca el contenido de un cubo sobre otro.
   * Antes de echar el agua se comprueba cuanto le cabe al
   * cubo destino.
   */
  void vuelcaEn(Cubo destino) {
	int libres = destino.getCapacidad() - destino.getContenido();
    
	if (libres > 0) { // Si queda hueco en el cubo destino
		  if (this.contenido <= libres) {// Si cabe el contenido del cubo  en el cubo destino, vaciamos todo
			destino.setContenido(destino.getContenido() + this.contenido);
			this.vacia();
		} else { // Si no cabe todo, se echa lo que quepa
			this.contenido -= libres; // Saco del cubo solo lo que cabe en el destino
			destino.llena();// Actualizamos la situacion del cubo destino
		}
    }
  }
}
