package ejercicio5;
/**
 * PruebaCubo.java
 * Programa que prueba la clase Cubo
 */
public class PruebaCubo {
  public static void main(String[] args) {

    Cubo cuboP = new Cubo(2);
    Cubo cuboG = new Cubo(7);

    System.out.println("\nCubo peque�o: \n");
    cuboP.pinta();

    System.out.println("\nCubo grande: \n");
    cuboG.pinta();

    System.out.println("\nLleno el Cubo peque�o: \n");
    cuboP.llena();
    cuboP.pinta();

    System.out.println("\nEl Cubo grande sigue vacio: \n");
    cuboG.pinta();
    
    System.out.println("\nAhora vuelco lo que tiene el Cubo peque�o en el Cubo grande.\n");
    cuboP.vuelcaEn(cuboG);

    System.out.println("Cubo peque�o: \n");
    cuboP.pinta();

    System.out.println("\nCubo grande: \n");
    cuboG.pinta();

    System.out.println("\nAhora vuelco lo que tiene el Cubo grande en el Cubo peque�o.\n");
    cuboG.vuelcaEn(cuboP);

    System.out.println("Cubo peque�o: \n");
    cuboP.pinta();

    System.out.println("\nCubo grande: \n");
    cuboG.pinta();
  }
}
